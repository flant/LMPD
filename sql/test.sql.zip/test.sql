-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 21 2011 г., 23:21
-- Версия сервера: 5.1.49
-- Версия PHP: 5.3.3-7+squeeze1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `user` (`user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `user`) VALUES
(1, 'test@testtop.loc'),
(2, 'gaga@testtop.loc');

-- --------------------------------------------------------

--
-- Структура таблицы `white_list_addr`
--

CREATE TABLE IF NOT EXISTS `white_list_addr` (
  `id_wl_arrd` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mx_addr` varchar(255) NOT NULL,
  `accept` varchar(255) NOT NULL DEFAULT 'OK',
  PRIMARY KEY (`id_wl_arrd`),
  UNIQUE KEY `mx_addr` (`mx_addr`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `white_list_addr`
--

INSERT INTO `white_list_addr` (`id_wl_arrd`, `mx_addr`, `accept`) VALUES
(1, '192.168.0.1', 'OK'),
(2, '213.141.136.65', 'OK');

-- --------------------------------------------------------

--
-- Структура таблицы `white_list_dns`
--

CREATE TABLE IF NOT EXISTS `white_list_dns` (
  `id_wl_dns` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dns` varchar(255) NOT NULL,
  `accept` varchar(255) NOT NULL DEFAULT 'OK',
  PRIMARY KEY (`id_wl_dns`),
  UNIQUE KEY `dns` (`dns`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `white_list_dns`
--

INSERT INTO `white_list_dns` (`id_wl_dns`, `dns`, `accept`) VALUES
(1, 'mail.ru', 'OK'),
(2, 'auditory.ru', 'OK');

-- --------------------------------------------------------

--
-- Структура таблицы `white_list_mail`
--

CREATE TABLE IF NOT EXISTS `white_list_mail` (
  `id_wl_mail` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `mail` varchar(255) NOT NULL,
  `accept` varchar(255) NOT NULL DEFAULT 'OK',
  PRIMARY KEY (`id_wl_mail`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `white_list_mail`
--

INSERT INTO `white_list_mail` (`id_wl_mail`, `user_id`, `mail`, `accept`) VALUES
(1, 1, 'root@router.loc', 'OK'),
(2, 1, 'admin@klan-hub.ru', 'OK'),
(3, 2, 'romanov@klan-hub.ru', 'OK'),
(4, 2, 'gyrt@list.ru', 'OK'),
(7, 1, 'cs@klan-hub.ru', 'OK');
